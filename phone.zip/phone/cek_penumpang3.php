<?php
session_start();
include '../koneksi.php';
$id = $_GET['kode'];


$query = "SELECT * FROM penumpang WHERE id_penumpang = '$id' ";
$hasil = $connect -> query($query);
$data = $hasil -> fetch_array();

// cek kesesuaian password liat yang admin rada beda gitu karna langsung dari database bukan dari inputan
if ($id == $data['id_penumpang'])
{
// menyimpan username dan level ke dalam session
	echo "<script>window.open('system-penumpang.php?id=$id','_self')</script>";
}else{
}
	
?>

<script language="JavaScript">
window.alert("Maaf ID yang anda masukkan belum terdaftar");
window.location.href = 'gagal.html';
</script>


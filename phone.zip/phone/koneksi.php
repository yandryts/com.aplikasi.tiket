<?php
$host="localhost";
$user="root";
$pass="";
$db="tiket_bus";
// melakukan koneksi ke database
$connect = new mysqli($host,$user,$pass,$db);
 
// cek koneksi yang kita lakukan berhasil atau tidak
if ($connect->connect_error) {
   // jika terjadi error, matikan proses dengan die() atau exit();
   die('Maaf koneksi gagal: '. $connect->connect_error);
}